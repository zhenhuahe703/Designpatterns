public enum Singleton {
    INSTANCE;
}