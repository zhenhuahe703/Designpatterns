public interface Phone {
    void make();
}